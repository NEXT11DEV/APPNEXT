import SwiftUI
import Security

struct StoreApp: Codable, Identifiable {
    let id: String
    let name: String
    let version: String
    let description: String
    let icon_url: String?
    let available: Bool?
    let signing_supported: Bool?
}

struct SigningJob: Codable {
    let id: String
    let state: String
    let message: String?
    let install_url: String?
}

struct CatalogPage: Decodable {
    let apps: [StoreApp]
    let total: Int
    let page: Int
    let total_pages: Int
    let cached: Bool
}

enum Vault {
    static let service = "APPNEXT.Access"
    static func read() -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: "token",
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func save(_ value: String) -> Bool {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: "token"]
        let status = SecItemUpdate(query as CFDictionary,
            [kSecValueData as String: Data(value.utf8)] as CFDictionary)
        if status == errSecSuccess { return true }
        guard status == errSecItemNotFound else { return false }
        var item = query
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
    }
}

struct StoreError: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

@MainActor final class StoreModel: ObservableObject {
    @Published var apps: [StoreApp] = []
    @Published var loading = false
    @Published var activeID: String?
    @Published var status = ""
    @Published var error: String?
    @Published var installURL: URL?
    @Published var readyName = ""
    @Published var showInstall = false
    @Published var total = 0
    @Published var currentPage = 0
    @Published var totalPages = 1
    @Published var cached = false
    private var currentSearch = ""

    func request<T: Decodable>(_ path: String, server: String, method: String = "GET",
                               query: [URLQueryItem] = []) async throws -> T {
        guard let base = URL(string: server), base.scheme == "https", base.host != nil,
              base.user == nil, base.password == nil, base.query == nil,
              base.fragment == nil else { throw StoreError(text: "أدخل عنوان خادم HTTPS صحيحًا في الإعدادات") }
        let token = Vault.read()
        guard !token.isEmpty else { throw StoreError(text: "أدخل رمز الوصول في الإعدادات") }
        var components = URLComponents(url: base.appendingPathComponent(path), resolvingAgainstBaseURL: false)
        if !query.isEmpty { components?.queryItems = query }
        guard let url = components?.url else { throw StoreError(text: "عنوان طلب غير صحيح") }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 45
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw StoreError(text: "استجابة غير صحيحة") }
        guard (200...299).contains(http.statusCode) else {
            let detail = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            throw StoreError(text: detail?["message"] as? String ?? "تعذر الاتصال بالخادم (\(http.statusCode))")
        }
        return try JSONDecoder().decode(T.self, from: data)
    }

    func load(server: String, search: String = "", more: Bool = false) async {
        guard !loading else { return }
        loading = true
        defer { loading = false }
        do {
            let nextPage = more ? currentPage + 1 : 1
            let term = more ? currentSearch : search
            let result: CatalogPage = try await request("api/apps", server: server,
                query: [URLQueryItem(name: "page", value: String(nextPage)),
                        URLQueryItem(name: "search", value: term)])
            try Task.checkCancellation()
            if more {
                let known = Set(apps.map { $0.id })
                apps.append(contentsOf: result.apps.filter { !known.contains($0.id) })
            } else { apps = result.apps }
            total = result.total
            currentPage = result.page
            totalPages = result.total_pages
            cached = result.cached
            currentSearch = term
        } catch {
            if !Task.isCancelled { self.error = error.localizedDescription }
        }
    }

    func sign(_ app: StoreApp, server: String) async {
        guard activeID == nil else { return }
        activeID = app.id
        status = "بدء الطلب…"
        installURL = nil
        defer { activeID = nil }
        do {
            var job: SigningJob = try await request("api/apps/\(app.id)/sign", server: server, method: "POST")
            let deadline = Date().addingTimeInterval(900)
            while Date() < deadline {
                if job.state == "ready" {
                    guard let link = job.install_url, let url = URL(string: link),
                          url.scheme == "itms-services" else { throw StoreError(text: "رابط التثبيت غير صحيح") }
                    installURL = url
                    readyName = app.name
                    showInstall = true
                    status = "جاهز للتثبيت"
                    return
                }
                if job.state == "failed" { throw StoreError(text: job.message ?? "تعذر توقيع التطبيق") }
                status = ["queued": "في الانتظار…", "downloading": "جارٍ تنزيل التطبيق…",
                          "signing": "جارٍ توقيع التطبيق…"][job.state] ?? "جارٍ تجهيز التطبيق…"
                try await Task.sleep(nanoseconds: 2_000_000_000)
                job = try await request("api/jobs/\(job.id)", server: server)
            }
            throw StoreError(text: "انتهت مهلة الانتظار. تحقق من الخادم قبل إعادة المحاولة")
        } catch { self.error = error.localizedDescription; status = "" }
    }
}

@main struct APPNEXTApp: App {
    var body: some Scene {
        WindowGroup { StoreView().environment(\.layoutDirection, .rightToLeft) }
    }
}

struct StoreView: View {
    @StateObject private var model = StoreModel()
    @AppStorage("serverURL") private var server = ""
    @State private var search = ""
    @State private var settings = false
    @State private var searchTask: Task<Void, Never>?
    var filtered: [StoreApp] {
        model.apps.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 10) {
                        Image(systemName: "square.stack.3d.up.fill").font(.largeTitle)
                        Text("APPNEXT").font(.title2.bold())
                        Text("تطبيقات وألعاب في مكان واحد").font(.subheadline)
                    }
                    .foregroundStyle(.white).padding(24).frame(maxWidth: .infinity, alignment: .leading)
                    .background(LinearGradient(colors: [.indigo, .purple], startPoint: .topLeading,
                                               endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24))
                    Text("\(model.total) تطبيق ولعبة").font(.subheadline).foregroundStyle(.secondary)
                    if model.cached {
                        Text("المصدر غير متاح مؤقتًا؛ هذه نسخة محفوظة من القائمة")
                            .font(.caption).foregroundStyle(.orange)
                    }
                    if model.loading { ProgressView("جارٍ تحميل القائمة…").frame(maxWidth: .infinity) }
                    if !model.loading && filtered.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "square.grid.2x2").font(.largeTitle).foregroundStyle(.secondary)
                            Text(server.isEmpty ? "ابدأ بإعداد اتصال المتجر" : "لا توجد تطبيقات للعرض")
                            if server.isEmpty { Button("فتح الإعدادات") { settings = true }.buttonStyle(.borderedProminent) }
                        }.frame(maxWidth: .infinity).padding(30)
                    }
                    ForEach(filtered) { app in
                        HStack(spacing: 14) {
                            AsyncImage(url: URL(string: app.icon_url ?? "")) { image in
                                image.resizable().scaledToFill()
                            } placeholder: {
                                Image(systemName: "app.fill").font(.system(size: 32)).foregroundStyle(.indigo)
                            }.frame(width: 60, height: 60).background(.indigo.opacity(0.1))
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                            VStack(alignment: .leading, spacing: 5) {
                                Text(app.name).font(.headline)
                                Text("الإصدار \(app.version)").font(.caption).foregroundStyle(.secondary)
                                Text(app.description).font(.caption).foregroundStyle(.secondary)
                                if app.signing_supported == false {
                                    Text("يلزم ملف تعريف مناسب").font(.caption).foregroundStyle(.orange)
                                }
                                if model.activeID == app.id {
                                    Text(model.status).font(.caption).foregroundStyle(.indigo)
                                }
                            }
                            Spacer(minLength: 0)
                            Button {
                                Task { await model.sign(app, server: server) }
                            } label: {
                                if model.activeID == app.id { ProgressView() } else { Text("تثبيت").bold() }
                            }.buttonStyle(.bordered).tint(.indigo).disabled(model.activeID != nil || app.available == false || app.signing_supported == false)
                        }.padding(16).background(Color(.secondarySystemGroupedBackground),
                                                    in: RoundedRectangle(cornerRadius: 20))
                    }
                    if model.currentPage < model.totalPages {
                        Button("تحميل المزيد") { Task { await model.load(server: server, more: true) } }
                            .buttonStyle(.borderedProminent).disabled(model.loading)
                    }
                }.padding(20)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("APPNEXT")
            .searchable(text: $search, prompt: "ابحث عن تطبيق")
            .toolbar { Button { settings = true } label: { Image(systemName: "gearshape") } }
            .refreshable { if !server.isEmpty { await model.load(server: server, search: search) } }
            .task { if !server.isEmpty { await model.load(server: server) } }
            .sheet(isPresented: $settings) { SettingsView(server: $server) }
            .onChange(of: settings) { value in
                if !value && !server.isEmpty { Task { await model.load(server: server, search: search) } }
            }
            .onChange(of: search) { value in
                searchTask?.cancel()
                searchTask = Task {
                    try? await Task.sleep(nanoseconds: 500_000_000)
                    guard !Task.isCancelled, !server.isEmpty else { return }
                    await model.load(server: server, search: value)
                }
            }
            .alert("تعذر إكمال الطلب", isPresented: Binding(get: { model.error != nil },
                set: { if !$0 { model.error = nil } })) {
                    Button("حسنًا", role: .cancel) { model.error = nil }
                } message: { Text(model.error ?? "") }
            .alert("\(model.readyName) جاهز", isPresented: $model.showInstall) {
                Button("تثبيت الآن") {
                    if let url = model.installURL {
                        UIApplication.shared.open(url) { accepted in
                            if !accepted { Task { @MainActor in model.error = "تعذر فتح رابط التثبيت على هذا الجهاز" } }
                        }
                    }
                }
                Button("إلغاء", role: .cancel) {}
            } message: { Text("سيطلب iOS تأكيد التثبيت. يجب أن يكون جهازك مشمولًا بملف التعريف.") }
        }
    }
}

struct SettingsView: View {
    @Binding var server: String
    @Environment(\.dismiss) private var dismiss
    @State private var draftURL = ""
    @State private var token = ""
    @State private var message: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("اتصال المتجر") {
                    TextField("https://store.example.com", text: $draftURL)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .environment(\.layoutDirection, .leftToRight)
                    SecureField("رمز الوصول", text: $token).textInputAutocapitalization(.never)
                        .autocorrectionDisabled().environment(\.layoutDirection, .leftToRight)
                }
                Section {
                    Text("رمز الوصول محفوظ في سلسلة مفاتيح الجهاز. ملفات الشهادة محفوظة على خادم التوقيع.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                if let message { Text(message).foregroundStyle(.red) }
            }
            .navigationTitle("الإعدادات")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("إلغاء") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("حفظ") {
                        let value = draftURL.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard let url = URL(string: value), url.scheme == "https", url.host != nil,
                              url.user == nil, url.password == nil, url.query == nil, url.fragment == nil,
                              token.count >= 32 else {
                            message = "أدخل عنوان HTTPS ورمز وصول من 32 حرفًا على الأقل"; return
                        }
                        guard Vault.save(token) else { message = "تعذر حفظ رمز الوصول"; return }
                        server = value
                        dismiss()
                    }
                }
            }
            .onAppear { draftURL = server; token = Vault.read() }
        }.environment(\.layoutDirection, .rightToLeft)
    }
}

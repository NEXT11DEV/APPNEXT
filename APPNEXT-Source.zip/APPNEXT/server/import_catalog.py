"""Import public store metadata and download links, not IPA binaries."""
import concurrent.futures
import html
import json
from pathlib import Path
import re
import subprocess
import time
from urllib.parse import urlencode, urlparse

API = 'https://download.hassanyipa.workers.dev/v1/store'
ORIGIN = 'https://download.hassanyipa.workers.dev'
HEADERS = {'Origin': 'https://hassanystore.pages.dev',
           'Referer': 'https://hassanystore.pages.dev/', 'Accept': 'application/json'}


def page(number, search='', attempts=3):
    params = {'per_page': 6, 'page': number, 'orderby': 'date', 'order': 'desc'}
    if search:
        params['search'] = search
    url = API + '?' + urlencode(params)
    for attempt in range(attempts):
        try:
            command = ['curl', '-fsSL', '--max-time', '25']
            for key, value in HEADERS.items():
                command.extend(['-H', f'{key}: {value}'])
            result = json.loads(subprocess.run(command + [url], capture_output=True,
                                               check=True, timeout=30).stdout)
            if not result.get('ok') or not isinstance(result.get('data'), list):
                raise ValueError('Store did not return a public catalog page')
            return result
        except Exception:
            if attempt == attempts - 1:
                raise
            time.sleep(1 + attempt)


def clean(value):
    return html.unescape(re.sub('<[^>]+>', '', str(value or ''))).strip()


def convert(item):
    details = item.get('app_details') or {}
    downloads = item.get('downloads') or []
    first = downloads[0] if downloads else {}
    route = item.get('__hassany_download')
    source = ORIGIN + route if route and route.startswith('/v1/d/') else first.get('download_url', '')
    image = item.get('__hassany_image', '')
    return {
        'id': str(item['id']),
        'name': clean(details.get('name') or (item.get('title') or {}).get('rendered')),
        'version': clean(details.get('version') or first.get('download_version') or 'غير محدد'),
        'description': clean(details.get('size') or first.get('download_size') or 'الحجم غير محدد'),
        'bundle_identifier': clean(details.get('bundle')),
        'source_url': source,
        'icon_url': ORIGIN + image if image.startswith('/v1/i/') else '',
        'profiles': ['device.mobileprovision'],
        'download_filename': 'Next.ipa',
        'available': bool(source and urlparse(source).scheme == 'https')
    }


if __name__ == '__main__':
    first = page(1)
    pages = {1: first['data']}
    count = first['totalPages']
    cache = Path(__file__).parent / '.catalog-cache'
    cache.mkdir(exist_ok=True)
    (cache / '1.json').write_text(json.dumps(first, ensure_ascii=False))
    for number in range(2, count + 1):
        cached = cache / f'{number}.json'
        if cached.exists() and time.time() - cached.stat().st_mtime < 3600:
            records = json.loads(cached.read_text())
            if isinstance(records, list):
                pages[number] = records
    print(f'Fetching {count} public catalog pages; total reported: {first["total"]}', flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        pending = {pool.submit(page, n): n for n in range(2, count + 1) if n not in pages}
        for future in concurrent.futures.as_completed(pending):
            n = pending[future]
            pages[n] = future.result()['data']
            (cache / f'{n}.json').write_text(json.dumps(pages[n], ensure_ascii=False))
            if len(pages) % 10 == 0 or len(pages) == count:
                print(f'Pages {len(pages)}/{count}', flush=True)
    records = {}
    for n in sorted(pages):
        for item in pages[n]:
            records.setdefault(str(item['id']), convert(item))
    destination = Path(__file__).parent / 'catalog.json'
    destination.write_text(json.dumps(list(records.values()), ensure_ascii=False, indent=2))
    print(f'Saved {len(records)} distinct records; {sum(a["available"] for a in records.values())} with HTTPS download links', flush=True)
    (Path(__file__).parent / 'catalog-import.json').write_text(json.dumps({
        'imported_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'source': 'https://hassanystore.pages.dev', 'reported_total': first['total'],
        'imported_count': len(records), 'pages': count,
        'includes_ipa_binaries': False}, indent=2))

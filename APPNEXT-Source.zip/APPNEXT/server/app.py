"""Single-user signing service. Run behind an HTTPS reverse proxy on loopback."""
import datetime as dt
import fnmatch
from functools import lru_cache
import hmac
import json
import os
from pathlib import Path, PurePosixPath
import plistlib
import secrets
import sys
import shutil
import struct
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, quote, parse_qs
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import import_catalog as source_store
DATA = Path(os.environ.get('DATA_DIR', ROOT / 'data')).resolve()
SECRETS = Path(os.environ.get('SIGNING_DIR', ROOT / 'secrets')).resolve()
CATALOG = json.loads((ROOT / 'catalog.json').read_text())
PUBLIC = os.environ.get('PUBLIC_URL', '').rstrip('/')
TOKEN = os.environ.get('STORE_TOKEN', '')
LOCK = threading.Lock()
JOBS = {}
TTL = 3600
MAX_BYTES = 500 * 1024 * 1024
LIVE_CATALOG = os.environ.get('LIVE_CATALOG', '1') == '1'
CATALOG_LOCK = threading.Lock()


def ipa_info(path):
    with zipfile.ZipFile(path) as archive:
        files = archive.infolist()
        if sum(f.file_size for f in files) > 2 * 1024**3:
            raise ValueError('حجم التطبيق بعد فك الضغط أكبر من الحد المسموح')
        for f in files:
            p = PurePosixPath(f.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in f.filename:
                raise ValueError('مسار غير صالح داخل ملف IPA')
            if (f.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('الروابط الرمزية غير مدعومة في هذه النسخة')
        mains = [f.filename for f in files if f.filename.startswith('Payload/')
                 and f.filename.endswith('.app/Info.plist') and f.filename.count('/') == 2]
        if len(mains) != 1:
            raise ValueError('يجب أن يحتوي الملف على تطبيق رئيسي واحد')
        bundles = [mains[0]] + [f.filename for f in files if f.filename.startswith('Payload/')
                                and f.filename.endswith('.appex/Info.plist')]
        if any('/Watch/' in f.filename for f in files):
            raise ValueError('تطبيقات الساعة تحتاج إعداد توقيع إضافيًا')
        infos = []
        for name in bundles:
            info = plistlib.loads(archive.read(name))
            executable = info.get('CFBundleExecutable', '')
            if not executable or '/' in executable or executable in ('.', '..'):
                raise ValueError('اسم الملف التنفيذي غير صالح')
            binary = archive.read(str(PurePosixPath(name).parent / executable))
            reject_encrypted(binary)
            infos.append(info)
        return infos


def reject_encrypted(binary):
    # Fail closed for unsupported executable formats; never decrypt apps.
    if len(binary) < 32:
        raise ValueError('الملف التنفيذي غير صالح')
    magic = binary[:4]
    if magic in (b'\xca\xfe\xba\xbe', b'\xca\xfe\xba\xbf'):
        count = struct.unpack_from('>I', binary, 4)[0]
        width = 32 if magic[-1] == 0xbf else 20
        if count > 16 or 8 + width * count > len(binary):
            raise ValueError('الملف التنفيذي غير صالح')
        for i in range(count):
            pos = 8 + i * width
            fmt = '>QQ' if width == 32 else '>II'
            offset, size = struct.unpack_from(fmt, binary, pos + 8)
            reject_encrypted(binary[offset:offset + size])
        return
    if magic not in (b'\xcf\xfa\xed\xfe', b'\xce\xfa\xed\xfe'):
        raise ValueError('صيغة الملف التنفيذي غير مدعومة')
    count = struct.unpack_from('<I', binary, 16)[0]
    pos = 32 if magic[0] == 0xcf else 28
    if count > 10000:
        raise ValueError('الملف التنفيذي غير صالح')
    for _ in range(count):
        if pos + 8 > len(binary):
            raise ValueError('الملف التنفيذي غير صالح')
        command, size = struct.unpack_from('<II', binary, pos)
        if size < 8 or pos + size > len(binary):
            raise ValueError('الملف التنفيذي غير صالح')
        if command in (0x21, 0x2c):
            if size < 20 or struct.unpack_from('<I', binary, pos + 16)[0] != 0:
                raise ValueError('هذا التطبيق مشفر ولا يمكن إعادة توقيعه بهذه الخدمة')
        pos += size


def prepare_signing(app, infos, work):
    from cryptography.hazmat.primitives.serialization import pkcs12, Encoding, PrivateFormat, NoEncryption
    from cryptography import x509
    password = os.environ.get('P12_PASSWORD', '').encode() or None
    key, cert, _ = pkcs12.load_key_and_certificates((SECRETS / 'certificate.p12').read_bytes(), password)
    now = dt.datetime.now(dt.timezone.utc)
    if not key or not cert or not (cert.not_valid_before_utc <= now < cert.not_valid_after_utc):
        raise ValueError('الشهادة غير صالحة أو لا تحتوي على المفتاح الخاص')
    profiles = []
    patterns = []
    for name in app['profiles']:
        if Path(name).name != name:
            raise ValueError('اسم ملف التعريف غير صالح')
        path = SECRETS / name
        decoded = subprocess.run(['openssl', 'cms', '-verify', '-inform', 'DER', '-noverify',
                                  '-in', str(path)], capture_output=True, timeout=30, check=True).stdout
        profile = plistlib.loads(decoded)
        expiry = profile['ExpirationDate'].replace(tzinfo=dt.timezone.utc)
        if expiry <= now:
            raise ValueError('ملف التعريف منتهي الصلاحية')
        if not profile.get('ProvisionedDevices') and not profile.get('ProvisionsAllDevices'):
            raise ValueError('ملف توزيع المتجر لا يدعم التثبيت المباشر')
        allowed = [x509.load_der_x509_certificate(c).public_bytes(Encoding.DER)
                   for c in profile.get('DeveloperCertificates', [])]
        if cert.public_bytes(Encoding.DER) not in allowed:
            raise ValueError('الشهادة لا تطابق ملف التعريف')
        identifier = profile['Entitlements']['application-identifier']
        patterns.append(identifier.split('.', 1)[1])
        profiles.extend(['-m', str(path)])
    for info in infos:
        if not any(fnmatch.fnmatchcase(info['CFBundleIdentifier'], p) for p in patterns):
            raise ValueError('يلزم ملف تعريف مطابق للتطبيق وامتداداته')
    # Keep unencrypted temporary key inside a private job directory; delete in finally.
    pem = work / 'identity.pem'
    fd = os.open(pem, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
        f.write(cert.public_bytes(Encoding.PEM))
    return pem, profiles


def perform(job_id, app):
    work = DATA / job_id
    pem = None
    try:
        work.mkdir(mode=0o700)
        source = work / 'source.ipa'
        if urlparse(app['source_url']).scheme != 'https':
            raise ValueError('رابط المصدر يجب أن يستخدم HTTPS')
        JOBS[job_id]['state'] = 'downloading'
        subprocess.run(['curl', '-fsSL', '--max-time', '300', '--max-filesize', str(MAX_BYTES),
                        '--proto', '=https', '--proto-redir', '=https',
                        '-H', 'Origin: https://hassanystore.pages.dev',
                        '-H', 'Referer: https://hassanystore.pages.dev/',
                        app['source_url'], '-o', str(source)],
                       capture_output=True, check=True, timeout=310)
        if source.stat().st_size > MAX_BYTES:
            raise ValueError('تجاوز التنزيل حد الحجم')
        infos = ipa_info(source)
        JOBS[job_id]['state'] = 'signing'
        pem, profiles = prepare_signing(app, infos, work)
        target = work / 'Next.ipa'
        subprocess.run([os.environ.get('ZSIGN_BIN', 'zsign'), '-f', '-k', str(pem),
                        *profiles, '-o', str(target), str(source)], cwd=work,
                       capture_output=True, check=True, timeout=600)
        info = ipa_info(target)[0]
        manifest = {'items': [{'assets': [{'kind': 'software-package',
            'url': f'{PUBLIC}/files/{job_id}/Next.ipa'}], 'metadata': {
            'bundle-identifier': info['CFBundleIdentifier'],
            'bundle-version': info.get('CFBundleVersion', '1'),
            'kind': 'software', 'title': info.get('CFBundleDisplayName', app['name'])}}]}
        (work / 'manifest.plist').write_bytes(plistlib.dumps(manifest))
        url = f'{PUBLIC}/files/{job_id}/manifest.plist'
        JOBS[job_id].update(state='ready', install_url='itms-services://?action=download-manifest&url=' + quote(url, safe=''))
    except ValueError as e:
        JOBS[job_id].update(state='failed', message=str(e))
    except Exception:
        JOBS[job_id].update(state='failed', message='تعذر التنزيل أو التوقيع. تحقق من إعداد الخادم والشهادة.')
    finally:
        if pem:
            pem.unlink(missing_ok=True)
        (work / 'source.ipa').unlink(missing_ok=True)
        if JOBS[job_id]['state'] == 'failed':
            shutil.rmtree(work, ignore_errors=True)
        LOCK.release()


@lru_cache(maxsize=1024)
def profile_pattern(name):
    if Path(name).name != name:
        return None
    try:
        decoded = subprocess.run(['openssl', 'cms', '-verify', '-inform', 'DER', '-noverify',
                                  '-in', str(SECRETS / name)], capture_output=True, timeout=30, check=True).stdout
        identifier = plistlib.loads(decoded)['Entitlements']['application-identifier']
        return identifier.split('.', 1)[1]
    except Exception:
        return None


def public_app(app):
    output = {k: app[k] for k in ('id', 'name', 'version', 'description')}
    output['icon_url'] = app.get('icon_url', '')
    output['available'] = app.get('available', True)
    bundle = app.get('bundle_identifier', '')
    output['signing_supported'] = bool(bundle and any(
        pattern and fnmatch.fnmatchcase(bundle, pattern)
        for pattern in (profile_pattern(name) for name in app['profiles'])))
    return output


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # Do not log private capability URLs or credentials.

    def send_json(self, status, body):
        data = json.dumps(body, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def authorized(self):
        return hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + TOKEN)

    def do_GET(self):
        path = urlparse(self.path).path
        if path.startswith('/files/'):
            parts = path.split('/')
            if len(parts) != 4 or parts[3] not in ('manifest.plist', 'Next.ipa'):
                return self.send_json(404, {})
            job = JOBS.get(parts[2])
            if not job or job['state'] != 'ready' or time.time() - job['created'] > TTL:
                return self.send_json(404, {})
            file = DATA / parts[2] / parts[3]
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream' if parts[3].endswith('ipa') else 'application/xml')
            self.send_header('Content-Length', str(file.stat().st_size))
            self.send_header('Cache-Control', 'no-store')
            if parts[3].endswith('.ipa'):
                self.send_header('Content-Disposition', 'attachment; filename="Next.ipa"')
            self.end_headers()
            with file.open('rb') as f:
                shutil.copyfileobj(f, self.wfile, 1024 * 1024)
            return
        if not self.authorized():
            return self.send_json(401, {'message': 'رمز الوصول غير صحيح'})
        if path == '/api/apps':
            query = parse_qs(urlparse(self.path).query)
            try:
                page_number = int(query.get('page', ['1'])[0])
                search = query.get('search', [''])[0]
                if not 1 <= page_number <= 10000 or len(search) > 200:
                    raise ValueError()
            except ValueError:
                return self.send_json(400, {'message': 'طلب قائمة غير صحيح'})
            if LIVE_CATALOG:
                try:
                    result = source_store.page(page_number, search, attempts=1)
                    apps = [source_store.convert(item) for item in result['data']]
                    with CATALOG_LOCK:
                        configured = {app['id']: app for app in CATALOG}
                        for app in apps:
                            if app['id'] in configured:
                                app['profiles'] = configured[app['id']]['profiles']
                            configured[app['id']] = app
                        CATALOG[:] = list(configured.values())
                    return self.send_json(200, {'apps': [public_app(a) for a in apps],
                        'total': int(result.get('total', len(apps))), 'page': page_number,
                        'total_pages': int(result.get('totalPages', 1)), 'cached': False})
                except Exception:
                    if page_number != 1:
                        return self.send_json(502, {'message': 'المصدر غير متاح حاليًا. حاول تحميل المزيد بعد قليل'})
            with CATALOG_LOCK:
                apps = [a for a in CATALOG if not search or search.casefold() in a['name'].casefold()]
                size = 6
                selected = apps[(page_number-1)*size:page_number*size]
                return self.send_json(200, {'apps': [public_app(a) for a in selected],
                    'total': len(apps), 'page': page_number,
                    'total_pages': max(1, (len(apps)+size-1)//size), 'cached': LIVE_CATALOG})
        if path.startswith('/api/jobs/'):
            job = JOBS.get(path.split('/')[-1])
            if job and time.time() - job['created'] <= TTL:
                return self.send_json(200, job)
        self.send_json(404, {'message': 'غير موجود'})

    def do_POST(self):
        if not self.authorized():
            return self.send_json(401, {'message': 'رمز الوصول غير صحيح'})
        parts = urlparse(self.path).path.split('/')
        app = next((a for a in CATALOG if len(parts) == 5 and parts[1:3] == ['api', 'apps']
                    and parts[3] == a['id'] and parts[4] == 'sign'), None)
        if not app:
            return self.send_json(404, {'message': 'التطبيق غير موجود'})
        if app.get('available') is False:
            return self.send_json(422, {'message': 'رابط تنزيل التطبيق غير متوفر'})
        if app.get('bundle_identifier') and not public_app(app)['signing_supported']:
            return self.send_json(422, {'message': 'يلزم ملف تعريف يغطي معرّف هذا التطبيق'})
        if not LOCK.acquire(blocking=False):
            return self.send_json(409, {'message': 'هناك عملية توقيع جارية، حاول بعد قليل'})
        job_id = secrets.token_urlsafe(32)
        JOBS[job_id] = {'id': job_id, 'state': 'queued', 'created': time.time()}
        threading.Thread(target=perform, args=(job_id, app), daemon=True).start()
        self.send_json(202, JOBS[job_id])


def cleanup():
    while True:
        time.sleep(60)
        for job_id, job in list(JOBS.items()):
            if job['state'] in ('ready', 'failed') and time.time() - job['created'] > TTL:
                JOBS.pop(job_id, None)
                shutil.rmtree(DATA / job_id, ignore_errors=True)


if __name__ == '__main__':
    if len(TOKEN) < 32 or urlparse(PUBLIC).scheme != 'https' or not urlparse(PUBLIC).netloc:
        raise SystemExit('Set STORE_TOKEN (32+ characters) and PUBLIC_URL (public HTTPS origin).')
    os.umask(0o077)
    DATA.mkdir(parents=True, exist_ok=True)
    # Ephemeral jobs cannot be resumed after restart.
    for directory in DATA.iterdir():
        if directory.is_dir():
            shutil.rmtree(directory)
    threading.Thread(target=cleanup, daemon=True).start()
    ThreadingHTTPServer(('127.0.0.1', int(os.environ.get('PORT', '8080'))), Handler).serve_forever()

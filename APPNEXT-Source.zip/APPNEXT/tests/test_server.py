import importlib.util
import io
import json
from pathlib import Path
import plistlib
import struct
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import zipfile

spec = importlib.util.spec_from_file_location('server', Path(__file__).parents[1] / 'server/app.py')
server = importlib.util.module_from_spec(spec)
spec.loader.exec_module(server)
server.LIVE_CATALOG = False
server.CATALOG = [{'id': 'teledark', 'name': 'Teledark', 'version': '12.8', 'description': 'Test', 'profiles': ['test.mobileprovision']}] 


def binary(encrypted=False):
    header = struct.pack('<8I', 0xfeedfacf, 0x100000c, 0, 2, 1, 24, 0, 0)
    return header + struct.pack('<6I', 0x2c, 24, 0, 0, int(encrypted), 0)


def make_ipa(path, encrypted=False, extra=None):
    with zipfile.ZipFile(path, 'w') as z:
        z.writestr('Payload/Test.app/Info.plist', plistlib.dumps({
            'CFBundleIdentifier': 'com.test.app', 'CFBundleExecutable': 'Test', 'CFBundleVersion': '7'}))
        z.writestr('Payload/Test.app/Test', binary(encrypted))
        if extra:
            z.writestr(extra, 'bad')


class PackageTests(unittest.TestCase):
    def test_valid_package_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp) / 'test.ipa'
            make_ipa(file)
            self.assertEqual(server.ipa_info(file)[0]['CFBundleIdentifier'], 'com.test.app')

    def test_encrypted_package_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp) / 'test.ipa'
            make_ipa(file, encrypted=True)
            with self.assertRaisesRegex(ValueError, 'مشفر'):
                server.ipa_info(file)

    def test_path_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp) / 'test.ipa'
            make_ipa(file, extra='../../outside')
            with self.assertRaisesRegex(ValueError, 'مسار'):
                server.ipa_info(file)

    def test_truncated_macho_rejected(self):
        with self.assertRaises(ValueError):
            server.reject_encrypted(binary()[:-1])

    def test_fat_encrypted_slice_rejected(self):
        part = binary(True)
        fat = struct.pack('>7I', 0xcafebabe, 1, 0x100000c, 0, 28, len(part), 0) + part
        with self.assertRaisesRegex(ValueError, 'مشفر'):
            server.reject_encrypted(fat)


class APITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        server.TOKEN = 'test-token-' + 'x' * 32
        cls.http = server.ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        cls.origin = f'http://127.0.0.1:{cls.http.server_port}'
        threading.Thread(target=cls.http.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown()
        cls.http.server_close()

    def call(self, path, method='GET', auth=True):
        headers = {'Authorization': 'Bearer ' + server.TOKEN} if auth else {}
        return urlopen(Request(self.origin + path, headers=headers, method=method), timeout=5)

    def test_catalog_requires_authentication(self):
        with self.assertRaises(HTTPError) as e:
            self.call('/api/apps', auth=False)
        self.assertEqual(e.exception.code, 401)

    def test_catalog_does_not_disclose_signing_paths(self):
        with self.call('/api/apps') as r:
            apps = json.load(r)['apps']
        self.assertEqual(apps[0]['id'], 'teledark')
        self.assertNotIn('profiles', apps[0])
        self.assertNotIn('source_url', apps[0])

    def test_unlisted_app_cannot_be_signed(self):
        with self.assertRaises(HTTPError) as e:
            self.call('/api/apps/unknown/sign', method='POST')
        self.assertEqual(e.exception.code, 404)

    def test_concurrent_sign_request_rejected(self):
        server.LOCK.acquire()
        try:
            with self.assertRaises(HTTPError) as e:
                self.call('/api/apps/teledark/sign', method='POST')
            self.assertEqual(e.exception.code, 409)
        finally:
            server.LOCK.release()

    def test_unknown_download_is_not_public(self):
        with self.assertRaises(HTTPError) as e:
            self.call('/files/unknown/Next.ipa', auth=False)
        self.assertEqual(e.exception.code, 404)

    def test_specific_profile_does_not_allow_other_bundle(self):
        app = dict(server.CATALOG[0], bundle_identifier='com.some.other.app')
        with patch.object(server, 'profile_pattern', return_value='com.registered.app'):
            self.assertFalse(server.public_app(app)['signing_supported'])

    def test_wildcard_profile_allows_matching_main_bundle(self):
        app = dict(server.CATALOG[0], bundle_identifier='com.some.other.app')
        with patch.object(server, 'profile_pattern', return_value='com.some.*'):
            self.assertTrue(server.public_app(app)['signing_supported'])

    def test_signed_download_filename(self):
        import time
        with tempfile.TemporaryDirectory() as temp, patch.object(server, 'DATA', Path(temp)):
            job_id = 'temporary-capability'
            folder = Path(temp) / job_id
            folder.mkdir()
            (folder / 'Next.ipa').write_bytes(b'test-package')
            server.JOBS[job_id] = {'state': 'ready', 'created': time.time()}
            try:
                with self.call(f'/files/{job_id}/Next.ipa', auth=False) as response:
                    self.assertEqual(response.headers['Content-Disposition'], 'attachment; filename="Next.ipa"')
                    self.assertEqual(response.read(), b'test-package')
            finally:
                server.JOBS.pop(job_id)

    def test_live_catalog_queries_remote_page_and_search(self):
        response = {'ok': True, 'data': [{'id': 999, 'app_details': {'name': 'TestApp',
            'bundle': 'com.test.app', 'version': '1'}, '__hassany_download': '/v1/d/999'}],
            'total': 11563, 'totalPages': 643}
        with patch.object(server, 'LIVE_CATALOG', True), patch.object(server, 'CATALOG', []), \
                patch.object(server.source_store, 'page', return_value=response) as remote:
            with self.call('/api/apps?page=334&search=TestApp') as result:
                page = json.load(result)
            remote.assert_called_once_with(334, 'TestApp', attempts=1)
            self.assertEqual(page['total'], 11563)
            self.assertEqual(page['apps'][0]['id'], '999')
            self.assertFalse(page['cached'])

    def test_live_catalog_failure_is_labelled_as_cached(self):
        with patch.object(server, 'LIVE_CATALOG', True), \
                patch.object(server.source_store, 'page', side_effect=RuntimeError('Unavailable')):
            with self.call('/api/apps') as result:
                page = json.load(result)
            self.assertTrue(page['cached'])


if __name__ == '__main__':
    unittest.main()

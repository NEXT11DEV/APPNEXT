const ORIGIN = 'https://download.hassanyipa.workers.dev';
const clean = value => String(value ?? '').replace(/<[^>]*>/g, '').replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();
const json = (value, status = 200) => new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store'}});
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'GET' && ['/', '/health'].includes(url.pathname)) return json({service: 'APPNEXT', status: 'ok', mode: 'catalogue'});
    if (!env.STORE_TOKEN || env.STORE_TOKEN.length < 32) return json({error: 'أضف STORE_TOKEN في إعدادات الخادم'}, 503);
    if (request.headers.get('Authorization') !== `Bearer ${env.STORE_TOKEN}`) return json({error: 'رمز الاتصال غير صحيح'}, 401);
    if (request.method === 'POST') return json({error: 'خدمة التوقيع لم تفعّل بعد'}, 503);
    if (request.method !== 'GET' || url.pathname !== '/api/apps') return json({error: 'غير موجود'}, 404);
    const page = Number(url.searchParams.get('page') || 1);
    if (!Number.isSafeInteger(page) || page < 1 || page > 10000) return json({error: 'رقم الصفحة غير صحيح'}, 400);
    const upstream = new URL('/v1/store', ORIGIN);
    for (const [key, value] of Object.entries({per_page: '6', page: String(page), orderby: 'date', order: 'desc'})) upstream.searchParams.set(key, value);
    const search = (url.searchParams.get('search') || '').trim().slice(0, 200);
    if (search) upstream.searchParams.set('search', search);
    try {
      const response = await fetch(upstream, {headers: {Origin: 'https://hassanystore.pages.dev', Referer: 'https://hassanystore.pages.dev/', Accept: 'application/json'}, signal: AbortSignal.timeout(25000)});
      if (!response.ok) throw new Error('upstream');
      const result = await response.json();
      if (!result.ok || !Array.isArray(result.data)) throw new Error('format');
      const apps = result.data.map(item => {
        const details = item.app_details || {};
        const first = item.downloads?.[0] || {};
        const route = item.__hassany_download || '';
        const available = route.startsWith('/v1/d/') || String(first.download_url || '').startsWith('https://');
        const image = item.__hassany_image || '';
        return {id: String(item.id), name: clean(details.name || item.title?.rendered), version: clean(details.version || first.download_version || 'غير محدد'), description: clean(details.size || first.download_size || 'الحجم غير محدد'), icon_url: image.startsWith('/v1/i/') ? ORIGIN + image : '', available, signing_supported: false};
      });
      return json({apps, total: Number(result.total || apps.length), page, total_pages: Number(result.totalPages || 1), cached: false});
    } catch {
      return json({error: 'تعذر الاتصال بمصدر التطبيقات، جرّب مرة ثانية'}, 502);
    }
  }
};
